<?php
class Uzivatel extends CI_Controller 
{
	public function __construct()
	{
	parent::__construct();
	$this->load->database();
	$this->load->helper('url');
	}
        
        public function index()
        {
            $this->load->view('formular');
        }

	public function save()
	{
		
            $n=$this->input->post('jmeno');
            $e=$this->input->post('email');
            $p=$this->input->post('heslo');

            $que=$this->db->query("select * from form where email=?", [$e]);
            $row = $que->num_rows();
            if($row)
            {
                
                $data['error']="<h3>Tento e-mail je již registrován</h3>";
            }
            else
            {
                $que=$this->db->query("insert into form (jmeno, email, heslo) values(?, ?, ?)", [$n, $e, $p]);

                $data['error']="<h3>Odesláno</h3>";
            }			

            $this->load->view('formular', $data);	
	}
}

