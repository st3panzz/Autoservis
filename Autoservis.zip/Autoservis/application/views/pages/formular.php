<?php
    $connect = mysqli_connect("localhost","root","","mydb");
    if(isset($_POST['submitinserdetails'])) {
        
        $datum = $_POST['datum'];
        $zavada = $_POST['zavada'];
        $vymenene_soucastky = $_POST['vymenene_soucastky'];
        $cas = $_POST['cas'];
        $naklady = $_POST['naklady'];
        
    if(!empty($datum) && !empty($zavada) && !empty($vymenene_soucastky) && !empty($cas) && !empty($naklady) )   {
    
        
        $sql = "INSERT INTO `oprava`(`datum`, `zavada`, `vymenene_soucastky`, `cas`, `naklady`)"
                               . " VALUES ('$datum','$zavada','$vymenene_soucastky','$cas','$naklady')" ;
    $qry = mysqli_query($connect, $sql);
    if($qry){
        echo "Oprava byla úspěšně zaznamenána.";
    }   
        
    } else {
        echo "Musí být vyplněné všechny kolonky!";
    }
    }
?>
<html>
    <head>
        <title>Zaznamenání opravy</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css">
        <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</head>
    <body>
        <div class="container">
         <div><br>&nbsp</div>
        <div class="text-center">
        <a href="<?php echo base_url('auth/formularmajitele');?>"><button type="button" class="btn btn-outline-primary">Vytvoření nového zákazníka</button></a>  
        <a href="<?php echo base_url('auth/formularzamestnanci');?>"><button type="button" class="btn btn-outline-primary">Založení nového zaměstnance</button></a>
        <a href="<?php echo base_url('auth/tabulkaoprav');?>"><button type="button" class="btn btn-outline-primary">Seznam oprav</button></a>
        </div>
        <div><br>&nbsp</div>
        <h1 class="text-center">Zaznamenání opravy</h1>
        <form class="text-center" action="" method="POST">
          <br><label for="datum">Datum:</label> <br><input type="text" name="datum">
<br><label for="zavada">Závada:</label><br><input type="text" name="zavada">
<br><label for="vymenene_soucastky">Vyměněné součástky:</label><br><input type="text" name="vymenene_soucastky">
<br><label for="cas">Čas:</label><br><input type="text" name="cas">
<br><label for="naklady">Náklady:</label><br><input type="text" name="naklady" ><br ><br >
<br><input type="submit" name="submitinserdetails" value="Odeslat">
</form>
        </div>
    </body>
</html>