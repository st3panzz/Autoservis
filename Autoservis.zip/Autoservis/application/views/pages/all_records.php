<!DOCTYPE html>
<html>
<head>
  <title>Zaměstnanci</title>
  <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css">
        <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
<?php

include "dbConn.php"; // Using database connection file here

$records = mysqli_query($db,"select * from zamestnanci"); // fetch data from database

?>
  <div class="container" class="text-center">
      <p>&nbsp</p>
      <a href="<?php echo base_url("auth/formularzamestnanci");?>"><button type="submit" class="btn btn-outline-primary">Založení nového zaměstnance</button></a>
      <a href="<?php echo base_url() . "auth/updatezamestnanci"; ?>"<button type="submit" class="btn btn-outline-primary">Upravit zaměstnance</button></a>
      <p>&nbsp</p>
<h1>Seznam zaměstnanců</h1>

<div class="row">
        <?php while($data = mysqli_fetch_array($records))
{
?>
        
        <div class="col">
    <div class="card" style="width: 18rem; height: 7rem;">
        <p class="hlava">ID: <?php echo $data['id']; ?></p> 
            <h4>Jméno: <?php echo $data['jmeno']; ?> <?php echo$data['prijmeni']; ?></h4>
                <p>Osobní číslo: <?php echo $data['osobni_cislo']; ?>
                    <a href="delete/<?php echo $data['id']; ?>">Smazat</a></p>            
    </div>
         <p>&nbsp</p>
     </div>
    <p>&nbsp</p>
        <?php } ?>
        
  </div>
    <p>&nbsp</p>
    </div>
<p>&nbsp</p>
  </div>
</div>
</body>
</html>
