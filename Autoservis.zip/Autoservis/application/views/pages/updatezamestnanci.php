<?php
$connection = mysqli_connect("localhost","root","");
$db = mysqli_select_db($connection,'mydb');

if(isset($_POST['update']))
{
    $id = $_POST['id'];
    
    $query = "UPDATE zamestnanci SET jmeno='$_POST[jmeno]',prijmeni='$_POST[prijmeni]',osobni_cislo='$_POST[osobni_cislo]' where id='$_POST[id]' ";
    $query_run = mysqli_query($connection,$query);
    
    if($query_run)
    {
        echo "<p>Data byla upravena!</p>";
    }
    else
    {
        echo "<p>Data nebyla upravena!</p>";
    }
}
?>
<center>
    <p>&nbsp</p>
    <h1>Upravení dat o zaměstnaních:</h1>
     <form class="text-center" action="" method="POST">
          <br><label for="id">ID:</label> <br><input type="text" name="id">
          <br><label for="jmeno">Jméno:</label><br><input type="text" name="jmeno">
<br><label for="prijmeni">Příjmení:</label><br><input type="text" name="prijmeni">
<br><label for="osobni_cislo">Osobní číslo:</label><br><input type="text" name="osobni_cislo"><br>
<br><input type="submit" name="update" value="Odeslat">
</form>
</center>
