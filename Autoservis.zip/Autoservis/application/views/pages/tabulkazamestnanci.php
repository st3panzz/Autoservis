<html>
    <head>
    </head>
    <body>
<div><br>&nbsp</div>

<div class="container">
  <div class="vertical-center">
        <a href="<?php echo base_url("auth/formularzamestnanci");?>"><button type="submit" class="btn btn-outline-primary">Založení nového zaměstnance</button></a>
  </div>
 <div><br>&nbsp</div>
  <div class="container" class="text-center">
<h1>Seznam zaměstnanců:</h1>
    <table class="table">
       <div class="row">
       <?php foreach ($zamestnanci as $zamest) { ?>
          <div class="col">
         <div class="card" style="width: 15rem; height: 13rem;">
    <h5>Jméno: <?= $zamest->jmeno; ?></h5>
            <p>Přijmení: <?= $zamest->prijmeni; ?></p>
            <p>Osobní číslo: <?= $zamest->osobni_cislo; ?></p>
    </div>
        <p>&nbsp</p>
  </div>
    <?php } ?>
    </div>
    </table>
</div>
</div>
    </body>
</html>

