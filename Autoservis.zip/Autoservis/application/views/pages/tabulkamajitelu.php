<html>
    <head>
    </head>
<body>
<div><br>&nbsp</div>

<div class="container">
  <div class="vertical-center">
        <a href="<?php echo base_url("auth/formularmajitele");?>"><button type="submit" class="btn btn-outline-primary">Vytvoření nového zákazníka</button></a>
        <a href="<?php echo base_url() . "auth/updatemajitelu"; ?>"<button type="submit" class="btn btn-outline-primary">Upravit zákazníka</button></a>
  </div>
 <div><br>&nbsp</div>
  <div class="container" class="text-center">
<h1>Seznam zákazníků:</h1>
    <table class="table">
       <div class="row">
       <?php foreach ($majitel_vozu as $majit_v) { ?>
          <div class="col">
         <div class="card" style="width: 18rem; height: 14rem;">
            <p>ID: <?= $majit_v->id; ?></p>
             <h5>Jméno: <?= $majit_v->jmeno; ?></h5>
            <p>Přijmení: <?= $majit_v->prijmeni; ?></p>
            <p>Adresa: <?= $majit_v->adresa; ?></p>
            <p>Telefon: <?= $majit_v->telefon; ?></p>   
            <p>Email: <?= $majit_v->email; ?></p>
            <div class="center">
  </div>
    </div>
       <p>&nbsp</p>
  </div>
    <?php } ?>
    </div>
    </table>
</div>
</div>
    </body>
</html>

