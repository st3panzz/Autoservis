<html>
    <head>
    </head>
<body>
<div><br>&nbsp</div>

<div class="container">
  <div class="vertical-center">
        <a href="<?php echo base_url("auth/formularmajitele");?>"><button type="submit" class="btn btn-outline-primary">Vytvoření nového zákazníka</button></a>
  </div>
 <div><br>&nbsp</div>
  <div class="container" class="text-center">
<h1>Seznam zákazníků:</h1>
    <table class="table">
       <div class="row">
       <?php foreach ($majitel_vozu as $majit_v) { ?>
          <div class="col">
         <div class="card" style="width: 15rem; height: 13rem;">
            <h5>Jméno: <?= $majit_v->jmeno; ?></h5>
            <p>Přijmení: <?= $majit_v->prijmeni; ?></p>
            <p>Adresa: <?= $majit_v->adresa; ?></p>
            <p>Telefon: <?= $majit_v->telefon; ?></p>   
            <p>Email: <?= $majit_v->email; ?></p>
    </div>
       <p>&nbsp</p>
  </div>
    <?php } ?>
    </div>
    </table>
</div>
</div>
    </body>
</html>

