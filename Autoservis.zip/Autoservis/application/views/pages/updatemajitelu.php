<?php
$connection = mysqli_connect("localhost","root","");
$db = mysqli_select_db($connection,'mydb');

if(isset($_POST['update']))
{
    $id = $_POST['id'];
    
    $query = "UPDATE majitel_vozu SET jmeno='$_POST[jmeno]',prijmeni='$_POST[prijmeni]',adresa='$_POST[adresa]',telefon='$_POST[telefon]',email='$_POST[email]' where id='$_POST[id]' ";
    $query_run = mysqli_query($connection,$query);
    
    if($query_run)
    {
        echo "<p>Data byla upravena.</p>";
    }
    else
    {
        echo "<p>Data nebyla upravena!</p>";
    }
}
?>
<center>
    <p>&nbsp</p>
    <h1 style="">Upravení dat o zákaznících:</h1>
     <form class="text-center" action="" method="POST">
          <br><label for="id">ID:</label> <br><input type="text" name="id">
          <br><label for="jmeno">Jméno:</label><br><input type="text" name="jmeno">
<br><label for="prijmeni">Příjmení:</label><br><input type="text" name="prijmeni">
<br><label for="adresa">Adresa:</label><br><input type="text" name="adresa">
<br><label for="telefon">Telefon:</label><br><input type="text" name="telefon">
<br><label for="email">Email:</label><br><input type="text" name="email"><br>
<br><input type="submit" name="update" value="Odeslat">
</form>
</center>




